package com.javatodev.api.model;

public enum LendStatus {
    AVAILABLE, BURROWED
}
