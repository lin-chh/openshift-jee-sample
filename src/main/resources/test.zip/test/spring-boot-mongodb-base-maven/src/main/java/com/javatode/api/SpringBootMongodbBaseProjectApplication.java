package com.javatode.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMongodbBaseProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootMongodbBaseProjectApplication.class, args);
    }

}
